scp -P 34874 ospf_geni.cpp cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028
scp -P 34875 ospf_geni.cpp cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028
scp -P 34876 ospf_geni.cpp cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028
scp -P 34877 ospf_geni.cpp cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028
scp -P 34878 ospf_geni.cpp cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028
scp -P 34879 ospf_geni.cpp cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028
scp -P 34880 ospf_geni.cpp cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028
ssh cs12b028@pc1.lan.sdn.uky.edu -p 34874 "g++ ospf_geni.cpp -o ospf -pthread;./ospf -f inp.txt -o out -i 0 > out0.txt" &
ssh cs12b028@pc1.lan.sdn.uky.edu -p 34875 "g++ ospf_geni.cpp -o ospf -pthread;./ospf -f inp.txt -o out -i 1 > out1.txt" &
ssh cs12b028@pc1.lan.sdn.uky.edu -p 34876 "g++ ospf_geni.cpp -o ospf -pthread;./ospf -f inp.txt -o out -i 2 > out2.txt" &
ssh cs12b028@pc1.lan.sdn.uky.edu -p 34877 "g++ ospf_geni.cpp -o ospf -pthread;./ospf -f inp.txt -o out -i 3 > out3.txt" &
ssh cs12b028@pc1.lan.sdn.uky.edu -p 34878 "g++ ospf_geni.cpp -o ospf -pthread;./ospf -f inp.txt -o out -i 4 > out4.txt" &
ssh cs12b028@pc1.lan.sdn.uky.edu -p 34879 "g++ ospf_geni.cpp -o ospf -pthread;./ospf -f inp.txt -o out -i 5 > out5.txt" &
ssh cs12b028@pc1.lan.sdn.uky.edu -p 34880 "g++ ospf_geni.cpp -o ospf -pthread;./ospf -f inp.txt -o out -i 6 > out6.txt" &
sleep 120
ssh cs12b028@pc1.lan.sdn.uky.edu -p 34874 "pkill ospf"
ssh cs12b028@pc1.lan.sdn.uky.edu -p 34875 "pkill ospf"
ssh cs12b028@pc1.lan.sdn.uky.edu -p 34876 "pkill ospf"
ssh cs12b028@pc1.lan.sdn.uky.edu -p 34877 "pkill ospf"
ssh cs12b028@pc1.lan.sdn.uky.edu -p 34878 "pkill ospf"
ssh cs12b028@pc1.lan.sdn.uky.edu -p 34879 "pkill ospf"
ssh cs12b028@pc1.lan.sdn.uky.edu -p 34880 "pkill ospf"
scp -P 34874 cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028/out-0.txt out-0.txt
scp -P 34875 cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028/out-1.txt out-1.txt
scp -P 34876 cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028/out-2.txt out-2.txt
scp -P 34877 cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028/out-3.txt out-3.txt
scp -P 34878 cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028/out-4.txt out-4.txt
scp -P 34879 cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028/out-5.txt out-5.txt
scp -P 34880 cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028/out-6.txt out-6.txt
scp -P 34874 cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028/out0.txt out0.txt
scp -P 34875 cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028/out1.txt out1.txt
scp -P 34876 cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028/out2.txt out2.txt
scp -P 34877 cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028/out3.txt out3.txt
scp -P 34878 cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028/out4.txt out4.txt
scp -P 34879 cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028/out5.txt out5.txt
scp -P 34880 cs12b028@pc1.lan.sdn.uky.edu:/users/cs12b028/out6.txt out6.txt