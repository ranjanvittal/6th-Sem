class LU2 {
	public static void main (String [] args) {
		int i;
		int t;
		t = 0;
		/* LOOPUNROLL 3 */
		for (i = 0; i < 7; i = i + 1) {
			t = i;
		}
		System.out.println(i);
		System.out.println(t);
	}
}
