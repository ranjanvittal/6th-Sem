run make to generate two output files ftpclient and ftpserver and run 
./ftpserver {some port no} on one system and ./ftpclient {same port no} localhost
on the other and give commands on the client side.